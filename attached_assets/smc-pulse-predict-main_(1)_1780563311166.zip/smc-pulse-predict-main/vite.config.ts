// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, cloudflare (build-only),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... } }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

const SERVER_FN_BASE = "/_server/fn/";

/**
 * Warm the SSR environment's module graph for known server function source
 * files at dev server startup. This ensures the TanStack Start compiler
 * registers their function IDs in the shared serverFnsById registry before
 * any client-originated RPC request arrives.
 *
 * Without this warmup, the SSR environment never transforms these files
 * (they are only dynamic-imported on the client), so the dev-mode
 * validate-server-fn-id plugin finds the ID missing and throws.
 */
function ssrServerFnWarmupPlugin() {
  let warmed = false;
  return {
    name: "ssr-server-fn-warmup",
    configureServer(server: { environments?: Record<string, { transformRequest: (path: string) => Promise<unknown> }> }) {
      const ssrEnv = server.environments?.ssr;
      if (!ssrEnv) return;
      const root = process.cwd().replace(/\\/g, "/");
      const files = [
        "/src/lib/crypto.functions.ts",
        "/src/lib/forex.functions.ts",
      ];
      const warm = async () => {
        if (warmed) return;
        warmed = true;
        for (const f of files) {
          const abs = root + f;
          try {
            await ssrEnv.transformRequest(abs);
          } catch {
            // transform may fail if the file triggers downstream errors;
            // function registration via the compiler's transform handler
            // already ran as a side-effect before any reject.
          }
        }
      };
      // Try immediately; fall back to idle callback if the environment
      // isn't ready yet.
      warm().catch(() => undefined);
    },
  };
}

// Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
// @cloudflare/vite-plugin builds from this — wrangler.jsonc main alone is insufficient.
export default defineConfig({
  tanstackStart: {
    server: { entry: "server" },
    serverFns: { base: "/_server/fn" },
  },
  plugins: [ssrServerFnWarmupPlugin()],
  vite: {
    define: {
      "process.env.TSS_SERVER_FN_BASE": JSON.stringify(SERVER_FN_BASE),
    },
  },
});
