# SMC Detection — How It Actually Works

This document is a candid, line-by-line walkthrough of the Smart Money Concept
engine that powers the app. It exists because ICT/SMC tooling is famously
hand-wavy and most public scripts will spam every 3-candle gap and call it an
FVG. We don't. This is the spec.

All tunables live in [`src/lib/smc/config.ts`](./src/lib/smc/config.ts).

---

## Pipeline

```
candles[]
   │
   ├─► atrSeries() + volumeSma()    shared volatility + volume scale
   │
   ├─► findPivots()                  swing structure, lookback = 3
   │       │
   │       ├─► analyzeStructure()     BOS / CHoCH state machine
   │       ├─► analyzeLiquidity()     weighted BSL / SSL pools
   │       ├─► equalLevels()          engineered EQH / EQL
   │       ├─► analyzeOrderBlocks()   true ICT OBs + Breakers + Mitigation
   │       └─► analyzeFVG()           displacement-filtered imbalances
   │
   ├─► analyzeDailyBias()            macro trend overlay (daily)
   ├─► analyzePDArray()              premium / discount zone mapping
   ├─► analyzeIFVG()                 filled FVGs that flipped
   └─► analyzeSMT()                  correlated-pair divergence
              │
              ▼
        buildReport()  →  Draw target + Alt target
```

Each module is single-purpose, side-effect free, and deterministic.

---

## 1. Pivots (`pivots.ts`)

- Classic `n`-bar fractal: a candle is a swing high if its high strictly
  exceeds the `n` candles on either side, mirrored for lows.
- `n = pivotLookback = 3` by default (so it sees 7-bar fractals).
- Cheap O(n · lookback). Pivots are the substrate every other agent runs on.
- ATR-based pivot prominence filtering is applied at the structure level, not
  during pivot detection itself (see §2a).

---

## 2. Structure — BOS / CHoCH (`structure.ts`)

The single biggest source of false signals in retail SMC scripts is structure
detection during ranging conditions. We fix this with three filters:

### a) ATR-relative pivot prominence
A raw pivot is only promoted into the state machine if its distance to the
nearest opposite pivot is **≥ `structureMinSwingAtr` × ATR** at that bar
(default `0.8`). Sub-ATR wiggles are discarded — they are not real swings.

### b) Close-confirmed breaks
A break only fires when a candle **closes** beyond the active swing. Wick-only
crosses are treated as **liquidity sweeps** (the liquidity agent already owns
that signal). This single rule kills the vast majority of false BOS prints
that retail indicators emit on ranges.

### c) Stateful BOS vs CHoCH
We walk every candle through the timeline maintaining:
- `activeHigh` — the most recent unbroken swing high
- `activeLow`  — the most recent unbroken swing low
- `bias`       — the current directional state

When a close breaks an active swing:
- **BOS** if the break extends the existing trend.
- **CHoCH** if the break is counter-trend (the first crack in the prior bias).

This is the correct definition. Most public tools call any swing break a BOS,
which is wrong as soon as price reverses.

Returned: `bias`, `lastEvent`, `lastEventPrice`, `lastEventTime`,
`lastSwingHigh`, `lastSwingLow`, `confidence`.

---

## 3. Order Blocks (`order-blocks.ts`)

A real ICT order block is **not** "the last opposite candle before a move."
That's the candidate. The qualifier is what matters:

### Requirements (all must hold)
1. Candle `i` is opposite-colored to the impulse.
2. The impulse candle `i+1` is the same color, body/range > `obBodyToRangeRatio`
   (default `0.6`).
3. Candle `i+2` closes beyond candle `i+1`'s extreme (continuation).
4. **Displacement**: impulse body ≥ `obImpulseMinAtr × ATR` (default `1.0×`).
   Without displacement, what you have is a pullback, not institutional intent.
5. **Volume spike**: impulse candle volume ≥ `volumeSpikeMin × SMA(volume, 20)`
   (default `1.5×`). Filters low-volume drift moves that lack institutional
   participation. Disabled when `volumeSpikeMin = 0`.
6. **FVG print**: the impulse leaves a Fair Value Gap relative to candle `i`
   (`obRequireFvg = true`). This is the canonical ICT requirement and is the
   single most powerful filter that separates real OBs from noise.

### Proximal / Distal lines (exposed explicitly)
- Bullish OB → `proximal = high`, `distal = low`
- Bearish OB → `proximal = low`,  `distal = high`

The proximal line is the entry trigger. The distal line is the invalidation.

### Lifecycle (`kind` field)
- **`OB`** — fresh, untagged.
- **`Mitigation`** — price has traded back past `obMitigationFraction` (default
  `0.5`, i.e. 50% of the body) from the proximal side. The OB has done its
  first job. It can still react on the second touch.
- **`Breaker`** — a closed-confirmed full violation. The OB flips: a former
  bullish OB that closes below its distal becomes a **bearish breaker** and
  is now resistance. This is the canonical breaker-block definition.

Fully-violated-without-flipping OBs are dropped from the output.

---

## 4. Fair Value Gaps (`fvg.ts`)

Default SMC scripts will print every 3-candle gap. That's noise. Our filter:

1. Standard 3-candle imbalance (next.low > prev.high for bullish, mirrored).
2. **Gap size ≥ `fvgMinGapAtr × ATR`** at the middle candle (default `0.25×`).
   Filters micro-gaps and thin-volume bar pairs.
3. **Middle-candle body ≥ `fvgMinDisplacementAtr × ATR`** (default `1.0×`).
   No displacement → not a real FVG. This is the rule that stops the spam.
4. **Volume spike**: middle-candle volume ≥ `volumeSpikeMin × SMA(volume, 20)`.
   Prevents low-volume gap fills from registering as institutional imbalances.
5. **Mitigation tracking**: each FVG carries a `fillFraction` (0 = untouched,
   1 = fully filled). FVGs above `fvgMitigationFraction` (default `0.5`) are
   dropped. The remainder are sorted by proximity to current price.

Each FVG also returns `gapAtr` and `displacementAtr` so the LLM agent can
reason about *quality*, not just presence.

---

## 5. Inversion FVGs (`fvg.ts → analyzeIFVG`)

An **inversion FVG** is a filled fair-value gap that later produces a strong
rejection bounce, flipping the zone's polarity from support to resistance (or
vice versa).

### Detection
1. Scan all 3-candle gaps that pass the `fvgMinGapAtr` filter.
2. Track whether price fills the gap (a candle's high crosses above the gap
   top for bullish FVGs, or crosses below the gap bottom for bearish).
3. After the fill, look for a reversal candle within `ifvgConfirmationBars`
   (default 5) that:
   - Has body ≥ `ifvgMinReversalAtr × ATR` (default `0.5×`).
   - Closes **back on the original gap side** (bearish rejection inside a
     formerly bullish gap, or bullish rejection inside a formerly bearish gap).
4. If all conditions hold, the gap is registered as an `InversionFVG` with
   type `"inversion"`, plus `reversalAtr`, `confirmationLag` (bars after
   fill), and `distance`.

### Why separate from regular FVGs?
The inversion FVG signals a **polarity flip** — the zone that was support is
now resistance. This is a different trading signal from a plain unfilled FVG,
so we surface them in a separate array. The breaker-block logic in
order-blocks.ts covers the same territory for single bars; IFVGs extend it to
gap-level zones.

---

## 6. Liquidity Pools (`liquidity.ts`)

Equal highs/lows are the baseline. The real edge is weighting which pool is
**actually engineered** and **actually a target**. We score every cluster on
four orthogonal dimensions:

### Clustering — O(n log n) sort + sweep
Pivots are sorted by price; adjacent prices within
`liquidityTolerance` (default 0.15%) of the cluster anchor are merged. No
nested loops, no O(n²) blowups.

### Composite score
```
score = touches × recency × session × displacement
```

- **`touches`** — raw count, equal-highs/lows weight higher organically.
- **`recency`** — exponential decay with `liquidityHalfLifeBars = 200`.
  Pools from 800 bars ago are worth 1/16 of fresh ones.
- **`session`** — multiplier based on the session in which the most recent
  touch formed:
  - `Asia: 1.3` — Asia highs/lows are textbook NY-session draws.
  - `London: 1.1`, `NY AM: 1.0`, `NY PM: 0.9`, `Off: 0.8`.
- **`displacement`** — the strongest body in the 3 bars after the pivot,
  ATR-scaled. Pools formed by strong reactions matter more than slow drifts.

### Sweep detection
Each pool exposes a `swept: boolean` — true when a later candle wicked
through the level but closed back on the original side (a wick-sweep
liquidity raid).

### Output ranking
Final order is by `score / (1 + |distance%|)` — high-quality, nearby pools
float to the top.

---

## 7. Premium / Discount Array (`pd-array.ts`)

ICT Premium/Discount Array identifies where price sits relative to the most
recent significant dealing range. This is a simplified single-range PD Array
(the full ICT model tracks multiple nested ranges; we surface the dominant one).

### Method
1. Find the most recent **significant swing high** using a 5-bar fractal filter
   with body/range ratio ≥ `pdArrayBodyRatio` (default `0.5`).
2. Find the most recent **significant swing low** using the same filter.
3. If the most recent swing is a high, pair it with the preceding significant
   low (and vice versa) to define a complete dealing range.
4. Compute:
   - **`midpoint`** = `(rangeHigh + rangeLow) / 2` — the fair value reference.
   - **`currentZone`**: `"premium"` if close ≥ midpoint, `"discount"` if below.
   - **`zoneDistance`**: scaled -1..+1 measuring deviation from midpoint.

### Application in draw scoring
Draw targets aligned with the PD zone get a 1.15× score boost:
- Bullish draws (BSL above) in **discount** → buy from cheap.
- Bearish draws (SSL below) in **premium** → sell from expensive.

This prevents the engine from recommending buys at the top of the range and
sells at the bottom — a common failure mode in pure-structure approaches.

---

## 8. Daily Bias Overlay (`daily-bias.ts`)

The daily-bias module provides a **macro-trend filter** independent of the
intraday structure agent. It uses two complementary signals:

### Signal 1 — Swing progression
On the daily candle series (passed separately from the intraday data), find
the three most recent ATR-filtered swing highs and lows. Test the progression:
- Higher highs + higher lows → **bullish**.
- Lower highs + lower lows → **bearish**.
- Mixed → **neutral**.

### Signal 2 — Price vs fast SMA
Compute SMA(period/2) of daily closes:
- Price above → **bullish**.
- Price below → **bearish**.
- Crossing → **neutral**.

### Combination
| Swing signal | MA signal | Result |
|-------------|-----------|--------|
| bullish | bullish | **strong bullish** (strength=1.0) |
| bullish | neutral | weak bullish (strength=0.5) |
| bearish | bearish | **strong bearish** (strength=1.0) |
| bearish | neutral | weak bearish (strength=0.5) |
| neutral | * | ranging (strength=0) |

### Application in draw scoring
Draws aligned with the daily bias receive a 1.2× score multiplier; draws
against it receive 0.8×. This forces the intraday engine to account for
macro context, reducing counter-trend recommendations during strong trends.

---

## 9. SMT Divergence (`smt.ts`)

Smart Money Technique (SMT) divergence compares the swing structure of a
primary symbol against a correlated pair. Divergence occurs when the two
pairs disagree at a turning point — one makes a higher high while the other
makes a lower high at the same structural moment.

### Method
1. Fractal swing-high and swing-low detection on both candle arrays (must be
   same timeframe). Each swing must meet `smtDivergenceAtr × ATR` prominence.
2. **Time alignment**: primary and pair swings are matched by timestamp within
   a tolerance of 1.5× the median bar interval.
3. For each matched pair of consecutive same-type swings (high-to-high,
   low-to-low), compare direction:

   | Primary | Pair | Signal |
   |---------|------|--------|
   | Higher high | Lower high | **Bearish divergence** — pair didn't confirm |
   | Lower low | Higher low | **Bullish divergence** — pair didn't confirm |

4. Severity is a function of how extreme the directional gap is (capped at
   `1.0`).

### Correlated pairs (known pairs)
- **Forex**: EURUSD ↔ GBPUSD, EURUSD ↔ USDCHF, GBPUSD ↔ USDJPY
- **Crypto**: BTCUSDT ↔ ETHUSDT, BTCUSDT ↔ SOLUSDT

SMT data is only computed when the caller provides `correlatedPairs` in the
`buildReport` options. Without pair data, `smt` is `undefined`.

### Current limitations
- Requires both pairs to be on the same exact timeframe.
- Time alignment assumes continuous markets (crypto 24/7); forex gaps near
  weekend opens may skip some matched swings.

---

## 10. Volume Confirmation (`volume.ts`)

A utility module shared across OB, FVG, and displacement detection.

### Volume SMA
- Simple moving average of raw volume over `volumeSmaPeriod` (default 20) bars.
- Early bars use an expanding window so every index is defined.
- If the average volume is zero (forex tick volume from Yahoo Finance), the
  spike check returns `true` unconditionally (can't confirm → skip rather
  than false-reject every bar).

### Where volume is applied
| Consumer | Bar checked | Effect |
|----------|------------|--------|
| `analyzeOrderBlocks` | Impulse candle `i+1` | Rejects OBs on low-volume drifts |
| `analyzeFVG` | Middle candle `i` | Rejects FVGs on low-volume gaps |
| `displacement()` | Last bar | Labels `volumeConfirmed` boolean |

The `volumeSpikeMin` config key (default `1.5`) controls strictness. Set to
`0` to disable volume confirmation entirely.

---

## 11. Sessions (`config.ts → sessionForTime`)

Bucketed in UTC:
- `Asia` 00–07
- `London` 07–12
- `NY AM` 12–16
- `NY PM` 16–21
- `Off` otherwise

Used by liquidity weighting and by the confidence-driver "session alignment"
check (long-only bias is downweighted outside London/NY killzones).

---

## 12. Draw on Liquidity (`report.ts`)

The Synthesizer picks one **draw** and one **alt** target from the ranked
liquidity pools. Score is the weighted blend in `drawWeights`:

- `proximity (0.4)` — distance to current price (linear up to `drawProximityRangePct`).
- `strength (0.3)` — touches capped at `drawStrengthCap`.
- `bias (0.3)` — alignment with structure (1.0 aligned, 0.5 neutral, 0.2 against).

### Enhanced multipliers (new)
- **Daily bias alignment** (×1.2 if aligned, ×0.8 if against).
- **PD array alignment** (×1.15 when drawing toward the "cheap" side of the
  dealing range).

The alt is the highest-scoring pool on the *opposite* side, so you always see
the counter-thesis on the card.

### Report shape
```typescript
{
  price, structure, liquidity, orderBlocks, fvgs, draw, alt,
  volumeDisplacement: { atrRatio, label, volumeConfirmed, volumeRatio },
  dailyBias?:       { bias, strength, consecutiveSwings, description },
  pdArray?:         { rangeHigh, rangeLow, midpoint, currentZone, zoneDistance, description },
  inversionFvgs?:   InversionFVG[],
  smt?:             SMTResult[],
}
```

All new fields are optional — existing callers that pass only candles get the
same object shape with the new fields populated where data is available.

---

## Tuning

Every threshold above lives in [`config.ts`](./src/lib/smc/config.ts). Keep
changes there — don't sprinkle constants in detection files.

### Quick-tuning guide
- **Too many FVGs**: raise `fvgMinDisplacementAtr` or `volumeSpikeMin`.
- **Too many OBs**: raise `obImpulseMinAtr` or `volumeSpikeMin`.
- **False BOS in range**: raise `structureMinSwingAtr`.
- **Liquidity pools too stale**: lower `liquidityHalfLifeBars`.
- **IFVGs not triggering**: lower `ifvgMinReversalAtr` or raise `ifvgConfirmationBars`.
- **SMT too sensitive**: raise `smtDivergenceAtr`.

If you tighten further, the natural next moves are:
- Daily/weekly bias as a separate structural pass with order-flow volume analysis.
- Volume profile / VPVR for support/resistance level discovery.
- A dedicated PD-array agent on multiple dealing ranges (nested).

---

## Known non-goals

- We do not annotate Judas swings explicitly; the sweep + CHoCH combination
  on a 5m/15m surfaces them implicitly.
- We do not model SMT divergence with more than one correlated pair per
  report call (callers can call `analyzeSMT` directly for multi-pair setups).
- We do not detect IFVGs retroactively on historical data — only the most
  recent `ifvgConfirmationBars` after each gap.

These are deliberate omissions, not bugs.
