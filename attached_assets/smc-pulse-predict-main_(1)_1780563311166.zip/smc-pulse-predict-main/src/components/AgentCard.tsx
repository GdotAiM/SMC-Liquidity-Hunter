import type { SmcReport } from "@/lib/smc/agents";
import type { Timeframe } from "@/lib/market";
import { fmt } from "@/lib/format";

function Bias({ bias }: { bias: "bullish" | "bearish" | "neutral" }) {
  const color =
    bias === "bullish"
      ? "text-bull bg-bull/10 border-bull/30"
      : bias === "bearish"
        ? "text-bear bg-bear/10 border-bear/30"
        : "text-muted-foreground bg-muted/40 border-border";
  return (
    <span
      className={`rounded border px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest ${color}`}
    >
      {bias}
    </span>
  );
}

export function AgentCard({
  tf,
  report,
  loading,
  error,
  refreshing,
  decimals,
  onOpen,
  onRetry,
}: {
  tf: Timeframe;
  report?: SmcReport;
  loading: boolean;
  error?: unknown;
  refreshing?: boolean;
  decimals: number;
  onOpen?: () => void;
  onRetry?: () => void;
}) {
  const hasBlockingError = !!error && !report;
  return (
    <button
      type="button"
      onClick={hasBlockingError ? onRetry : onOpen}
      className="w-full cursor-pointer rounded-lg border border-border bg-card p-4 text-left shadow-glow transition hover:border-accent/60 hover:bg-card/80 active:scale-[0.99]"
    >
      <header className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
            TF
          </span>
          <span className="font-mono text-lg font-bold text-accent">{tf}</span>
        </div>
        {refreshing ? (
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            updating
          </span>
        ) : report ? (
          <Bias bias={report.structure.bias} />
        ) : null}
      </header>

      {hasBlockingError ? (
        <div className="rounded-md border border-border bg-background/40 p-3">
          <div className="text-[10px] font-bold uppercase tracking-widest text-bear">
            Data feed unavailable
          </div>
          <div className="mt-1 text-[11px] text-muted-foreground">
            Tap to retry this timeframe.
          </div>
        </div>
      ) : loading || !report ? (
        <div className="space-y-2">
          <div className="h-3 w-full animate-pulse rounded bg-muted" />
          <div className="h-3 w-4/5 animate-pulse rounded bg-muted" />
          <div className="h-3 w-3/5 animate-pulse rounded bg-muted" />
        </div>
      ) : (
        <>
          {/* Draw target */}
          <div className="mb-3 rounded-md border border-accent/30 bg-accent/5 p-3">
            <div className="mb-1 text-[10px] font-bold uppercase tracking-widest text-accent">
              Next Draw on Liquidity
            </div>
            {report.draw ? (
              <>
                <div className="flex items-baseline justify-between">
                  <span
                    className={`font-mono text-xl font-bold ${
                      report.draw.side === "up" ? "text-bull" : "text-bear"
                    }`}
                  >
                    {report.draw.side === "up" ? "▲" : "▼"} {fmt(report.draw.price, decimals)}
                  </span>
                  <span className="font-mono text-xs text-muted-foreground">
                    {report.draw.distance.toFixed(2)}%
                  </span>
                </div>
                <div className="mt-1 text-[11px] text-muted-foreground">
                  {report.draw.reason} · conf {(report.draw.score * 100).toFixed(0)}%
                </div>
              </>
            ) : (
              <div className="text-xs text-muted-foreground">No clean target</div>
            )}
            {report.alt && (
              <div className="mt-2 border-t border-border pt-2 text-[11px] text-muted-foreground">
                Alt:{" "}
                <span className={report.alt.side === "up" ? "text-bull" : "text-bear"}>
                  {report.alt.side === "up" ? "▲" : "▼"} {fmt(report.alt.price, decimals)}
                </span>{" "}
                · {report.alt.distance.toFixed(2)}%
              </div>
            )}
          </div>

          {/* Agents grid */}
          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <Panel title="Structure">
              <div>{report.structure.lastEvent}</div>
              {report.structure.lastEventPrice && (
                <div className="text-muted-foreground">
                  @ {fmt(report.structure.lastEventPrice, decimals)}
                </div>
              )}
            </Panel>
            <Panel title="Liquidity">
              <div>
                <span className="text-bull">{report.liquidity.filter((l) => l.type === "BSL").length}</span>{" "}
                BSL ·{" "}
                <span className="text-bear">{report.liquidity.filter((l) => l.type === "SSL").length}</span>{" "}
                SSL
              </div>
            </Panel>
            <Panel title="Order Blocks">
              <div>
                <span className="text-bull">{report.orderBlocks.filter((b) => b.type === "bullish").length}↑</span>{" "}
                <span className="text-bear">{report.orderBlocks.filter((b) => b.type === "bearish").length}↓</span>
              </div>
              {report.orderBlocks[0] && (
                <div className="text-muted-foreground">
                  near {fmt((report.orderBlocks[0].top + report.orderBlocks[0].bottom) / 2, decimals)}
                </div>
              )}
            </Panel>
            <Panel title="FVG">
              <div>
                <span className="text-bull">{report.fvgs.filter((f) => f.type === "bullish").length}↑</span>{" "}
                <span className="text-bear">{report.fvgs.filter((f) => f.type === "bearish").length}↓</span>
              </div>
              {report.fvgs[0] && (
                <div className="text-muted-foreground">
                  near {fmt((report.fvgs[0].top + report.fvgs[0].bottom) / 2, decimals)}
                </div>
              )}
            </Panel>
          </div>
        </>
      )}
    </button>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded border border-border bg-background/40 p-2">
      <div className="mb-1 text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
        {title}
      </div>
      <div className="font-mono">{children}</div>
    </div>
  );
}
