// Shared chat & breakdown UI primitives used by every Intelligence Sheet.
import type { RefObject } from "react";

export type Msg = {
  role: "user" | "assistant" | "agent";
  agent?: string;
  content: string;
};

export type Tone = "bull" | "bear" | undefined;

export function Block({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-md border border-border bg-card/60 p-3">
      <div className="mb-2 text-[10px] font-bold uppercase tracking-widest text-accent">
        {title}
      </div>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

export function Row({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: Tone;
}) {
  const color =
    tone === "bull" ? "text-bull" : tone === "bear" ? "text-bear" : "text-foreground";
  return (
    <div className="flex items-baseline justify-between gap-3 text-[11px]">
      <span className="text-muted-foreground">{label}</span>
      <span className={`text-right font-mono ${color}`}>{value}</span>
    </div>
  );
}

export function Driver({
  ok,
  label,
  detail,
}: {
  ok: boolean;
  label: string;
  detail: string;
}) {
  return (
    <div className="flex items-start gap-2 text-[11px]">
      <span className={ok ? "text-bull" : "text-bear"}>{ok ? "✔" : "✖"}</span>
      <div>
        <div className="font-mono text-foreground">{label}</div>
        <div className="text-muted-foreground">{detail}</div>
      </div>
    </div>
  );
}

export function ChatBubble({ msg }: { msg: Msg }) {
  if (msg.role === "agent") {
    return (
      <div className="rounded border border-border bg-background/60 p-2">
        <div className="mb-0.5 text-[9px] font-bold uppercase tracking-widest text-accent">
          🤖 {msg.agent}
        </div>
        <div className="font-mono text-[11px] text-muted-foreground">{msg.content}</div>
      </div>
    );
  }
  if (msg.role === "assistant") {
    return (
      <div className="rounded border border-accent/40 bg-accent/5 p-2">
        <div className="mb-0.5 text-[9px] font-bold uppercase tracking-widest text-accent">
          ✦ {msg.agent ?? "Strategist"}
        </div>
        <div className="whitespace-pre-wrap text-[11px] text-foreground">{msg.content}</div>
      </div>
    );
  }
  return (
    <div className="ml-6 rounded border border-primary/30 bg-primary/10 p-2">
      <div className="mb-0.5 text-[9px] font-bold uppercase tracking-widest text-primary">
        You
      </div>
      <div className="whitespace-pre-wrap text-[11px]">{msg.content}</div>
    </div>
  );
}

export function AgentPipeline({
  title,
  messages,
  busy,
  scrollRef,
}: {
  title: string;
  messages: Msg[];
  busy: boolean;
  scrollRef: RefObject<HTMLDivElement | null>;
}) {
  return (
    <div ref={scrollRef} className="space-y-2 overflow-y-auto bg-background/40 p-3">
      <div className="mb-1 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
        {title}
      </div>
      {messages.map((m, i) => (
        <ChatBubble key={i} msg={m} />
      ))}
      {busy && (
        <div className="text-[11px] italic text-muted-foreground">agents thinking…</div>
      )}
    </div>
  );
}

export function ChatInput({
  value,
  onChange,
  onSend,
  disabled,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  onSend: () => void;
  disabled: boolean;
  placeholder: string;
}) {
  return (
    <div className="border-t border-border bg-card p-2">
      <div className="flex gap-2">
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && onSend()}
          placeholder={placeholder}
          aria-label="Ask the agents"
          className="flex-1 rounded border border-border bg-background px-3 py-2 text-xs outline-none focus:border-accent"
        />
        <button
          type="button"
          onClick={onSend}
          disabled={disabled}
          aria-label="Send message"
          className="rounded bg-accent px-3 py-2 text-xs font-bold uppercase tracking-wider text-accent-foreground disabled:opacity-50"
        >
          Send
        </button>
      </div>
    </div>
  );
}
