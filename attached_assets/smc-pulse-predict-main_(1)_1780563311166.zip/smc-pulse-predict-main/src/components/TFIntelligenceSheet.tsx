import { useMemo } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import type { SmcReport } from "@/lib/smc/agents";
import type { Candle, Timeframe } from "@/lib/market";
import {
  agentReasoningLog,
  buildConfidenceDrivers,
  currentSession,
  equalLevels,
} from "@/lib/smc/intelligence";
import { fmt } from "@/lib/format";
import {
  AgentPipeline,
  Block,
  ChatInput,
  Driver,
  Row,
  type Msg,
} from "@/components/smc/Chat";
import { useAgentChat } from "@/hooks/useAgentChat";

const SUMMARY_PROMPT =
  "In 2-3 sentences, write the Institutional Intent summary: what is smart money engineering right now and what is the most likely next draw on liquidity? Use trader language.";

export function TFIntelligenceSheet({
  open,
  onOpenChange,
  tf,
  symbol,
  report,
  htfReport,
  candles,
  decimals,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  tf: Timeframe;
  symbol: string;
  report?: SmcReport;
  htfReport?: SmcReport;
  candles?: Candle[];
  decimals: number;
}) {
  const drivers = useMemo(
    () => (report && candles ? buildConfidenceDrivers(report, htfReport, candles) : []),
    [report, htfReport, candles],
  );
  const reasoning = useMemo(
    () => (report && candles ? agentReasoningLog(report, candles) : []),
    [report, candles],
  );
  const eq = useMemo(() => (candles ? equalLevels(candles) : null), [candles]);

  const contextBlob = useMemo(() => {
    if (!report || !candles) return "";
    return JSON.stringify(
      {
        symbol,
        timeframe: tf,
        session: currentSession(),
        price: report.price,
        structure: report.structure,
        liquidity: report.liquidity,
        equalLevels: eq,
        orderBlocks: report.orderBlocks.slice(0, 3),
        fvgs: report.fvgs.slice(0, 3),
        draw: report.draw,
        alt: report.alt,
        htfBias: htfReport?.structure.bias,
        drivers,
      },
      null,
      2,
    );
  }, [report, candles, symbol, tf, eq, htfReport, drivers]);

  const seed = useMemo<Msg[]>(
    () =>
      reasoning.map((r) => ({ role: "agent", agent: r.agent, content: r.text })),
    [reasoning],
  );

  const { messages, input, setInput, send, scrollRef, busy } = useAgentChat({
    open,
    resetKey: `${symbol}|${tf}`,
    seed,
    contextBlob,
    summaryPrompt: SUMMARY_PROMPT,
    summaryAgentName: "Institutional Intent",
  });

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="bottom"
        className="h-[92vh] overflow-hidden border-accent/30 bg-background p-0"
      >
        <SheetHeader className="border-b border-border px-4 py-3 text-left">
          <SheetTitle className="flex items-baseline gap-2 font-display">
            <span className="font-mono text-accent">{tf}</span>
            <span className="text-sm text-muted-foreground">{symbol}</span>
            <span className="ml-auto rounded border border-accent/30 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-accent">
              Intelligence
            </span>
          </SheetTitle>
        </SheetHeader>

        <div className="grid h-[calc(92vh-56px)] grid-rows-[auto_1fr_auto] overflow-hidden">
          <div className="max-h-[40vh] space-y-3 overflow-y-auto border-b border-border p-4">
            {!report || !candles ? (
              <div className="text-sm text-muted-foreground">Loading…</div>
            ) : (
              <>
                <Block title="1. Structure">
                  <Row label="Bias" value={report.structure.bias.toUpperCase()} />
                  <Row label="Last MSS" value={report.structure.lastEvent} />
                  {report.structure.lastEventPrice && (
                    <Row label="At" value={fmt(report.structure.lastEventPrice, decimals)} />
                  )}
                </Block>

                <Block title="2. Liquidity Map">
                  {report.liquidity.filter((l) => l.type === "BSL").slice(0, 2).map((l, i) => (
                    <Row
                      key={`b${i}`}
                      label="BSL above"
                      value={`${fmt(l.price, decimals)} (+${l.distance.toFixed(2)}%) ×${l.strength}`}
                      tone="bull"
                    />
                  ))}
                  {report.liquidity.filter((l) => l.type === "SSL").slice(0, 2).map((l, i) => (
                    <Row
                      key={`s${i}`}
                      label="SSL below"
                      value={`${fmt(l.price, decimals)} (-${l.distance.toFixed(2)}%) ×${l.strength}`}
                      tone="bear"
                    />
                  ))}
                  {eq?.equalHighs && (
                    <Row label="Equal highs" value={fmt(eq.equalHighs.price, decimals)} tone="bull" />
                  )}
                  {eq?.equalLows && (
                    <Row label="Equal lows" value={fmt(eq.equalLows.price, decimals)} tone="bear" />
                  )}
                </Block>

                <Block title="3. Imbalance Zones">
                  {report.fvgs.length === 0 ? (
                    <Row label="FVGs" value="none unfilled" />
                  ) : (
                    report.fvgs.slice(0, 3).map((f, i) => (
                      <Row
                        key={i}
                        label={`${f.type === "bullish" ? "Bull" : "Bear"} FVG`}
                        value={`${fmt(f.bottom, decimals)} – ${fmt(f.top, decimals)}`}
                        tone={f.type === "bullish" ? "bull" : "bear"}
                      />
                    ))
                  )}
                </Block>

                <Block title="4. Order Flow">
                  <Row label="BOS / MSS" value={report.structure.lastEvent} />
                  <Row
                    label="Displacement"
                    value={`${reasoning.find((r) => r.agent === "Order Flow")?.text ?? ""}`}
                  />
                </Block>

                <Block title="5. Confidence Drivers">
                  {drivers.map((d) => (
                    <Driver key={d.label} ok={d.ok} label={d.label} detail={d.detail} />
                  ))}
                </Block>
              </>
            )}
          </div>

          <AgentPipeline
            title="Agent Pipeline · Live Reasoning"
            messages={messages}
            busy={busy}
            scrollRef={scrollRef}
          />

          <ChatInput
            value={input}
            onChange={setInput}
            onSend={send}
            disabled={busy || !input.trim()}
            placeholder="Ask the agents… e.g. why bearish draw?"
          />
        </div>
      </SheetContent>
    </Sheet>
  );
}
