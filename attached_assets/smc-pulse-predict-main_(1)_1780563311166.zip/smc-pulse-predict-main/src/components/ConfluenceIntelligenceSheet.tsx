import { useMemo } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import type { SmcReport } from "@/lib/smc/agents";
import type { Candle, Timeframe } from "@/lib/market";
import { currentSession, sessionAlignment } from "@/lib/smc/intelligence";
import { fmt } from "@/lib/format";
import {
  AgentPipeline,
  Block,
  ChatInput,
  Driver,
  Row,
  type Msg,
} from "@/components/smc/Chat";
import { useAgentChat } from "@/hooks/useAgentChat";

const SUMMARY_PROMPT =
  "In 2-3 sentences, write the Multi-Timeframe Institutional Intent: how do HTF and LTF align, what is smart money engineering across timeframes, and what is the dominant draw on liquidity? Use trader language.";

export function ConfluenceIntelligenceSheet({
  open,
  onOpenChange,
  symbol,
  timeframes,
  reports,
  candlesByTf,
  decimals,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  symbol: string;
  timeframes: Timeframe[];
  reports: (SmcReport | undefined)[];
  candlesByTf: (Candle[] | undefined)[];
  decimals: number;
}) {
  const agg = useMemo(() => {
    const rows = timeframes.map((tf, i) => ({
      tf,
      report: reports[i],
      candles: candlesByTf[i],
    }));
    const ready = rows.filter((r) => r.report);
    const ups = ready.filter((r) => r.report!.draw?.side === "up").length;
    const downs = ready.filter((r) => r.report!.draw?.side === "down").length;
    const bull = ready.filter((r) => r.report!.structure.bias === "bullish").length;
    const bear = ready.filter((r) => r.report!.structure.bias === "bearish").length;
    const neutral = ready.length - bull - bear;
    const side: "up" | "down" | "mixed" =
      ups > downs ? "up" : downs > ups ? "down" : "mixed";

    const htf = ready[ready.length - 1]?.report;
    const ltf = ready[0]?.report;
    const cascadeAligned =
      htf && ltf && htf.structure.bias !== "neutral"
        ? htf.structure.bias === ltf.structure.bias
        : false;

    const allBsl = ready.flatMap((r) =>
      r.report!.liquidity.filter((l) => l.type === "BSL").map((l) => ({ ...l, tf: r.tf })),
    );
    const allSsl = ready.flatMap((r) =>
      r.report!.liquidity.filter((l) => l.type === "SSL").map((l) => ({ ...l, tf: r.tf })),
    );
    allBsl.sort((a, b) => a.distance - b.distance);
    allSsl.sort((a, b) => a.distance - b.distance);

    const draws = ready
      .filter((r) => r.report!.draw)
      .map((r) => ({ tf: r.tf, draw: r.report!.draw! }))
      .sort((a, b) => b.draw.score - a.draw.score);

    return {
      rows: ready,
      ups,
      downs,
      bull,
      bear,
      neutral,
      side,
      htf,
      ltf,
      cascadeAligned,
      bsl: allBsl.slice(0, 3),
      ssl: allSsl.slice(0, 3),
      draws: draws.slice(0, 4),
    };
  }, [timeframes, reports, candlesByTf]);

  const session = currentSession();
  const sa = useMemo(
    () => sessionAlignment(agg.htf?.structure.bias ?? "neutral"),
    [agg.htf],
  );

  const contextBlob = useMemo(
    () =>
      JSON.stringify(
        {
          symbol,
          session,
          confluence: { side: agg.side, ups: agg.ups, downs: agg.downs },
          biasCounts: { bull: agg.bull, bear: agg.bear, neutral: agg.neutral },
          cascadeAligned: agg.cascadeAligned,
          htfBias: agg.htf?.structure.bias,
          ltfBias: agg.ltf?.structure.bias,
          topDraws: agg.draws,
          nearestBSL: agg.bsl,
          nearestSSL: agg.ssl,
          perTf: agg.rows.map((r) => ({
            tf: r.tf,
            bias: r.report!.structure.bias,
            lastEvent: r.report!.structure.lastEvent,
            draw: r.report!.draw,
          })),
        },
        null,
        2,
      ),
    [agg, symbol, session],
  );

  const seed = useMemo<Msg[]>(
    () => [
      {
        role: "agent",
        agent: "Confluence",
        content: `Across ${agg.rows.length} TFs: ${agg.ups}↑ / ${agg.downs}↓ draws. Bias: ${agg.bull} bull, ${agg.bear} bear, ${agg.neutral} neutral.`,
      },
      {
        role: "agent",
        agent: "HTF Cascade",
        content: agg.htf
          ? `Top TF (${timeframes[timeframes.length - 1]}) bias = ${agg.htf.structure.bias.toUpperCase()}. Bottom TF (${timeframes[0]}) bias = ${agg.ltf?.structure.bias.toUpperCase() ?? "n/a"}. ${
              agg.cascadeAligned ? "Cascade aligned ✔" : "Cascade unaligned ✖"
            }.`
          : "No HTF data yet.",
      },
      {
        role: "agent",
        agent: "Liquidity Pool",
        content: `Nearest BSL: ${
          agg.bsl[0]
            ? `${fmt(agg.bsl[0].price, decimals)} (${agg.bsl[0].tf}, +${agg.bsl[0].distance.toFixed(2)}%)`
            : "n/a"
        }. Nearest SSL: ${
          agg.ssl[0]
            ? `${fmt(agg.ssl[0].price, decimals)} (${agg.ssl[0].tf}, -${agg.ssl[0].distance.toFixed(2)}%)`
            : "n/a"
        }.`,
      },
      { role: "agent", agent: "Session", content: `${session} — ${sa.note}` },
      {
        role: "agent",
        agent: "Synthesizer",
        content: agg.draws[0]
          ? `Highest-prob draw: ${agg.draws[0].draw.side === "up" ? "▲" : "▼"} ${fmt(agg.draws[0].draw.price, decimals)} on ${agg.draws[0].tf} (${(agg.draws[0].draw.score * 100).toFixed(0)}%).`
          : "No clean draw across TFs — range conditions.",
      },
    ],
    [agg, timeframes, decimals, session, sa],
  );

  const { messages, input, setInput, send, scrollRef, busy } = useAgentChat({
    open,
    resetKey: symbol,
    seed,
    contextBlob,
    summaryPrompt: SUMMARY_PROMPT,
    summaryAgentName: "Institutional Intent (MTF)",
  });

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="bottom"
        className="h-[92vh] overflow-hidden border-accent/30 bg-background p-0"
      >
        <SheetHeader className="border-b border-border px-4 py-3 text-left">
          <SheetTitle className="flex items-baseline gap-2 font-display">
            <span className="font-mono text-accent">MTF</span>
            <span className="text-sm text-muted-foreground">{symbol} · Confluence</span>
            <span className="ml-auto rounded border border-accent/30 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-accent">
              Intelligence
            </span>
          </SheetTitle>
        </SheetHeader>

        <div className="grid h-[calc(92vh-56px)] grid-rows-[auto_1fr_auto] overflow-hidden">
          <div className="max-h-[42vh] space-y-3 overflow-y-auto border-b border-border p-4">
            <Block title="1. Cross-TF Bias">
              <Row
                label="Draws"
                value={`${agg.ups}↑ / ${agg.downs}↓ / ${agg.rows.length - agg.ups - agg.downs}◇`}
              />
              <Row label="Bullish TFs" value={String(agg.bull)} tone="bull" />
              <Row label="Bearish TFs" value={String(agg.bear)} tone="bear" />
              <Row
                label="Dominant"
                value={
                  agg.side === "up"
                    ? "▲ BULLISH"
                    : agg.side === "down"
                      ? "▼ BEARISH"
                      : "◇ MIXED"
                }
                tone={agg.side === "up" ? "bull" : agg.side === "down" ? "bear" : undefined}
              />
            </Block>

            <Block title="2. HTF → LTF Cascade">
              {agg.rows.map((r) => (
                <Row
                  key={r.tf}
                  label={r.tf}
                  value={`${r.report!.structure.bias.toUpperCase()} · ${r.report!.structure.lastEvent}${
                    r.report!.draw
                      ? ` · draw ${r.report!.draw.side === "up" ? "▲" : "▼"} ${fmt(r.report!.draw.price, decimals)}`
                      : ""
                  }`}
                  tone={
                    r.report!.structure.bias === "bullish"
                      ? "bull"
                      : r.report!.structure.bias === "bearish"
                        ? "bear"
                        : undefined
                  }
                />
              ))}
            </Block>

            <Block title="3. Pooled Liquidity Map">
              {agg.bsl.map((l, i) => (
                <Row
                  key={`b${i}`}
                  label={`BSL · ${l.tf}`}
                  value={`${fmt(l.price, decimals)} (+${l.distance.toFixed(2)}%) ×${l.strength}`}
                  tone="bull"
                />
              ))}
              {agg.ssl.map((l, i) => (
                <Row
                  key={`s${i}`}
                  label={`SSL · ${l.tf}`}
                  value={`${fmt(l.price, decimals)} (-${l.distance.toFixed(2)}%) ×${l.strength}`}
                  tone="bear"
                />
              ))}
            </Block>

            <Block title="4. Ranked Draw Targets">
              {agg.draws.length === 0 ? (
                <Row label="Draws" value="none" />
              ) : (
                agg.draws.map((d, i) => (
                  <Row
                    key={i}
                    label={`${d.tf}`}
                    value={`${d.draw.side === "up" ? "▲" : "▼"} ${fmt(d.draw.price, decimals)} · ${(d.draw.score * 100).toFixed(0)}% · ${d.draw.reason}`}
                    tone={d.draw.side === "up" ? "bull" : "bear"}
                  />
                ))
              )}
            </Block>

            <Block title="5. Confidence Drivers">
              <Driver
                ok={agg.cascadeAligned}
                label="HTF cascade alignment"
                detail={
                  agg.cascadeAligned
                    ? `Top & bottom TFs both ${agg.htf?.structure.bias}`
                    : "Top and bottom TFs disagree"
                }
              />
              <Driver ok={sa.ok} label="Session alignment" detail={sa.note} />
              <Driver
                ok={Math.abs(agg.ups - agg.downs) >= 2}
                label="Directional consensus"
                detail={`Net ${agg.ups - agg.downs > 0 ? "+" : ""}${agg.ups - agg.downs} across ${agg.rows.length} TFs`}
              />
              <Driver
                ok={!!agg.draws[0] && agg.draws[0].draw.score > 0.6}
                label="Strong primary draw"
                detail={
                  agg.draws[0]
                    ? `${(agg.draws[0].draw.score * 100).toFixed(0)}% on ${agg.draws[0].tf}`
                    : "no strong draw"
                }
              />
            </Block>
          </div>

          <AgentPipeline
            title="MTF Agent Pipeline · Live Reasoning"
            messages={messages}
            busy={busy}
            scrollRef={scrollRef}
          />

          <ChatInput
            value={input}
            onChange={setInput}
            onSend={send}
            disabled={busy || !input.trim()}
            placeholder="Ask… e.g. is HTF and LTF aligned?"
          />
        </div>
      </SheetContent>
    </Sheet>
  );
}
