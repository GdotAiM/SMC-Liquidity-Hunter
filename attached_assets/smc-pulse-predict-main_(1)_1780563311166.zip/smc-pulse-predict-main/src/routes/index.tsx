import { createFileRoute } from "@tanstack/react-router";
import { useQueries } from "@tanstack/react-query";
import { useCallback, useMemo, useState } from "react";
import {
  CRYPTO_SYMBOLS,
  FOREX_SYMBOLS,
  TF_GROUPS,
  fetchCandles,
  symbolLabel,
  type AssetClass,
  type Candle,
  type Timeframe,
} from "@/lib/market";
import { buildReport, type SmcReport } from "@/lib/smc/agents";
import { AgentCard } from "@/components/AgentCard";
import { TFIntelligenceSheet } from "@/components/TFIntelligenceSheet";
import { ConfluenceIntelligenceSheet } from "@/components/ConfluenceIntelligenceSheet";
import { fmt, inferDecimals } from "@/lib/format";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Liquidity Hunter — SMC Multi-Agent" },
      {
        name: "description",
        content:
          "Mobile SMC scanner for crypto & forex. Multi-timeframe agents (Structure, Liquidity, Order Blocks, FVG) predict the next draw on liquidity.",
      },
    ],
  }),
});

const GROUPS: { key: keyof typeof TF_GROUPS; label: string }[] = [
  { key: "scalp", label: "Scalp" },
  { key: "intraday", label: "Intraday" },
  { key: "swing", label: "Swing" },
  { key: "all", label: "All" },
];

const ASSET_CLASSES: { key: AssetClass; label: string }[] = [
  { key: "crypto", label: "Crypto" },
  { key: "forex", label: "Forex" },
];

// React Query caches the `select` result by reference, so `buildReport` only
// runs when new candles arrive — not on every component render.
type SmcQueryResult = { candles: Candle[]; report: SmcReport };

function Index() {
  const [asset, setAsset] = useState<AssetClass>("crypto");
  const [symbol, setSymbol] = useState("BTCUSDT");
  const [group, setGroup] = useState<keyof typeof TF_GROUPS>("intraday");
  const [openTf, setOpenTf] = useState<Timeframe | null>(null);
  const [openConfluence, setOpenConfluence] = useState(false);
  const timeframes = TF_GROUPS[group];
  const symbols = asset === "crypto" ? CRYPTO_SYMBOLS : FOREX_SYMBOLS;

  const handleAssetChange = useCallback((a: AssetClass) => {
    setAsset(a);
    setSymbol(a === "crypto" ? "BTCUSDT" : "EURUSD");
  }, []);

  const queries = useQueries({
    queries: timeframes.map((tf) => ({
      queryKey: ["candles", asset, symbol, tf],
      queryFn: () => fetchCandles(asset, symbol, tf),
      refetchInterval: asset === "crypto" ? 15_000 : 30_000,
      staleTime: 10_000,
      retry: 2,
      retryDelay: (attempt: number) => Math.min(1000 * 2 ** attempt, 5000),
      select: (candles: Candle[]): SmcQueryResult => ({
        candles,
        report: buildReport(candles),
      }),
    })),
  });

  const price =
    queries[0]?.data?.candles?.[queries[0].data!.candles.length - 1]?.close;
  const decimals = useMemo(
    () => inferDecimals(asset, symbol, price),
    [price, asset, symbol],
  );

  const reports = useMemo(() => queries.map((q) => q.data?.report), [queries]);
  const candlesByTf = useMemo(() => queries.map((q) => q.data?.candles), [queries]);

  const confluence = useMemo(() => {
    const ups = reports.filter((r) => r?.draw?.side === "up").length;
    const downs = reports.filter((r) => r?.draw?.side === "down").length;
    const total = reports.filter((r) => r?.draw).length;
    const loaded = reports.filter(Boolean).length;
    const failed = queries.filter((q) => q.isError && !q.data).length;
    const loading = queries.filter((q) => q.isLoading).length;
    const side: "up" | "down" | "mixed" =
      ups > downs ? "up" : downs > ups ? "down" : "mixed";
    return { side, ups, downs, total, loaded, failed, loading };
  }, [reports, queries]);

  const openTfIndex = openTf ? timeframes.indexOf(openTf) : -1;

  return (
    <div className="min-h-screen bg-background pb-12 text-foreground">
      <AppHeader asset={asset} price={price} decimals={decimals} />

      <main className="mx-auto max-w-md space-y-4 px-4 pt-4">
        <PillSelector
          label="Market"
          options={ASSET_CLASSES}
          value={asset}
          onChange={handleAssetChange}
          cols={2}
        />

        <SymbolStrip
          symbols={symbols}
          symbol={symbol}
          asset={asset}
          onChange={setSymbol}
        />

        <PillSelector
          label="Timeframes"
          options={GROUPS}
          value={group}
          onChange={setGroup}
          cols={4}
        />

        <ConfluenceCard confluence={confluence} onOpen={() => setOpenConfluence(true)} />

        <section className="space-y-3">
          {timeframes.map((tf, i) => (
            <AgentCard
              key={tf}
              tf={tf}
              report={reports[i]}
              loading={queries[i].isLoading}
              error={queries[i].error}
              refreshing={queries[i].isFetching && !!queries[i].data}
              decimals={decimals}
              onOpen={() => setOpenTf(tf)}
              onRetry={() => queries[i].refetch()}
            />
          ))}
        </section>

        {openTf && openTfIndex >= 0 && (
          <TFIntelligenceSheet
            open={!!openTf}
            onOpenChange={(o) => !o && setOpenTf(null)}
            tf={openTf}
            symbol={symbol}
            report={reports[openTfIndex]}
            htfReport={
              openTfIndex < timeframes.length - 1
                ? reports[openTfIndex + 1]
                : undefined
            }
            candles={candlesByTf[openTfIndex]}
            decimals={decimals}
          />
        )}

        <ConfluenceIntelligenceSheet
          open={openConfluence}
          onOpenChange={setOpenConfluence}
          symbol={symbol}
          timeframes={timeframes}
          reports={reports}
          candlesByTf={candlesByTf}
          decimals={decimals}
        />

        <footer className="pt-4 text-center text-[10px] uppercase tracking-widest text-muted-foreground">
          Educational tool · not financial advice
        </footer>
      </main>
    </div>
  );
}

function AppHeader({
  asset,
  price,
  decimals,
}: {
  asset: AssetClass;
  price: number | undefined;
  decimals: number;
}) {
  return (
    <header className="sticky top-0 z-10 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto max-w-md px-4 py-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-lg font-black tracking-tight">
              LIQUIDITY<span className="text-accent">.</span>HUNTER
            </h1>
            <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              SMC Multi-Agent · Draw on Liquidity
            </p>
          </div>
          <div className="text-right">
            <div className="font-mono text-base font-bold text-accent">
              {price !== undefined ? fmt(price, decimals) : "—"}
            </div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
              live · {asset === "crypto" ? "15s" : "30s"}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

function PillSelector<T extends string>({
  label,
  options,
  value,
  onChange,
  cols,
}: {
  label: string;
  options: { key: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  cols: 2 | 4;
}) {
  const colClass = cols === 2 ? "grid-cols-2" : "grid-cols-4";
  return (
    <section>
      <label className="mb-2 block text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
        {label}
      </label>
      <div className={`grid ${colClass} gap-2`}>
        {options.map((o) => (
          <button
            key={o.key}
            type="button"
            onClick={() => onChange(o.key)}
            aria-pressed={o.key === value}
            className={`rounded border px-2 py-2 text-xs font-bold uppercase tracking-wider transition ${
              o.key === value
                ? "border-accent bg-accent/10 text-accent"
                : "border-border bg-card text-muted-foreground"
            }`}
          >
            {o.label}
          </button>
        ))}
      </div>
    </section>
  );
}

function SymbolStrip({
  symbols,
  symbol,
  asset,
  onChange,
}: {
  symbols: string[];
  symbol: string;
  asset: AssetClass;
  onChange: (s: string) => void;
}) {
  return (
    <section>
      <label className="mb-2 block text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
        Symbol
      </label>
      <div className="flex gap-2 overflow-x-auto pb-1">
        {symbols.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => onChange(s)}
            aria-pressed={s === symbol}
            className={`shrink-0 rounded border px-3 py-1.5 font-mono text-xs font-bold transition ${
              s === symbol
                ? "border-accent bg-accent text-accent-foreground"
                : "border-border bg-card text-muted-foreground hover:border-accent/40"
            }`}
          >
            {symbolLabel(s, asset)}
          </button>
        ))}
      </div>
    </section>
  );
}

function ConfluenceCard({
  confluence,
  onOpen,
}: {
  confluence: {
    side: "up" | "down" | "mixed";
    ups: number;
    downs: number;
    loaded: number;
    failed: number;
    loading: number;
  };
  onOpen: () => void;
}) {
  const toneClass =
    confluence.side === "up"
      ? "text-bull"
      : confluence.side === "down"
        ? "text-bear"
        : "text-muted-foreground";
  const labelText =
    confluence.side === "up"
      ? "▲ BULLISH DRAW"
      : confluence.side === "down"
        ? "▼ BEARISH DRAW"
        : "◇ MIXED";
  return (
    <button
      type="button"
      onClick={onOpen}
      aria-label="Open multi-timeframe confluence intelligence"
      className="w-full rounded-lg border border-border bg-card p-4 text-left transition hover:border-accent/60"
    >
      <div className="mb-1 flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
        <span>Multi-Timeframe Confluence</span>
        <span className={confluence.failed ? "text-bear" : "text-accent"}>
          {confluence.failed ? "Feed degraded →" : "Tap for intelligence →"}
        </span>
      </div>
      <div className="flex items-center justify-between">
        <span className={`font-display text-2xl font-black ${toneClass}`}>{labelText}</span>
        <span className="font-mono text-xs text-muted-foreground">
          {confluence.ups}↑ / {confluence.downs}↓ · {confluence.loaded} live
        </span>
      </div>
      {confluence.failed > 0 && (
        <div className="mt-2 text-[11px] text-muted-foreground">
          {confluence.failed} timeframe feed failed. Open cards or switch symbol to retry.
        </div>
      )}
    </button>
  );
}
