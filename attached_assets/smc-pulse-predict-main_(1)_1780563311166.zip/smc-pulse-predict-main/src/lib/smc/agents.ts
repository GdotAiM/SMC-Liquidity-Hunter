// Barrel — kept for backward compatibility. New code should import from the
// focused modules.
export { findPivots, type Pivot } from "./pivots";
export {
  analyzeStructure,
  type StructureBias,
  type StructureResult,
} from "./structure";
export {
  analyzeLiquidity,
  equalLevels,
  type LiquidityPool,
} from "./liquidity";
export { analyzeOrderBlocks, type OrderBlock, type OrderBlockKind } from "./order-blocks";
export { analyzeFVG, analyzeIFVG, type FVG, type InversionFVG } from "./fvg";
export { buildReport, type DrawTarget, type SmcReport, type BuildReportOptions } from "./report";
export { analyzeDailyBias, type DailyBias, type DailyBiasResult } from "./daily-bias";
export { analyzePDArray, type PDZone, type PDArrayResult } from "./pd-array";
export { analyzeSMT, type SMTDivergence, type SMTDivergenceType, type SMTResult } from "./smt";
export { volumeSma, isVolumeSpike } from "./volume";
export {
  displacement,
  equalLevels as intelligenceEqualLevels,
  currentSession,
  sessionAlignment,
  buildConfidenceDrivers,
  agentReasoningLog,
  type SessionName,
  type ConfidenceDriver,
  type AgentThought,
} from "./intelligence";
