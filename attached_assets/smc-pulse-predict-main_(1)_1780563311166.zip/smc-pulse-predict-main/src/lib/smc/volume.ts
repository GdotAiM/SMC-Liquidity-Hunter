import type { Candle } from "../market";
import { SMC_CONFIG } from "./config";

/**
 * Simple moving average of volume over `period` bars.
 * Early bars use an expanding window so the array is defined for all indices.
 */
export function volumeSma(
  candles: Candle[],
  period = SMC_CONFIG.volumeSmaPeriod,
): number[] {
  const n = candles.length;
  const out: number[] = new Array(n).fill(0);
  if (n === 0) return out;

  let sum = 0;
  for (let i = 0; i < n; i++) {
    sum += candles[i].volume;
    if (i >= period) sum -= candles[i - period].volume;
    out[i] = i >= period - 1 ? sum / period : sum / (i + 1);
  }
  return out;
}

/**
 * True when the candle at `idx` has volume >= `volumeSpikeMin` × SMA(period).
 * If average volume over the window is zero (forex tick volume), returns true
 * (can't confirm → skip the check rather than false-reject every bar).
 */
export function isVolumeSpike(
  candles: Candle[],
  idx: number,
  sma: number[],
  minMultiplier = SMC_CONFIG.volumeSpikeMin,
): boolean {
  if (minMultiplier <= 0) return true;
  if (idx < 0 || idx >= candles.length) return false;
  const avg = sma[idx];
  if (avg === 0) return true; // zero-volume pair → skip check
  return candles[idx].volume / avg >= minMultiplier;
}
