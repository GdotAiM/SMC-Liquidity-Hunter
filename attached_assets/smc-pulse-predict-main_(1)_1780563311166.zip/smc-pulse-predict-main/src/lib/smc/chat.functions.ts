import { createServerFn } from "@tanstack/react-start";

type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

const DEFAULT_MODEL = "google/gemini-2.5-flash";

export const agentChat = createServerFn({ method: "POST" })
  .inputValidator(
    (data: { messages: ChatMessage[]; context: string; model?: string }) => data,
  )
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) {
      return {
        reply:
          "AI gateway not configured. Set LOVABLE_API_KEY to enable the assistant.",
        error: true,
      };
    }

    const systemPrompt = `You are the lead SMC (Smart Money Concepts) strategist coordinating a team of specialist agents: Structure, Liquidity, Order Blocks, FVG, Order Flow.

You receive the agents' raw findings as JSON-ish context and must:
1. Speak in trader language (BSL, SSL, BOS, CHoCH, MSS, FVG, OB, displacement, killzone, draw on liquidity).
2. Explain institutional intent — what smart money is engineering and why.
3. Be concise (under 120 words unless the user asks for depth).
4. Never give financial advice. This is educational analysis only.
5. If the user asks a question, answer using the agent context as ground truth.

CURRENT AGENT CONTEXT:
${data.context}`;

    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: data.model ?? DEFAULT_MODEL,
          messages: [{ role: "system", content: systemPrompt }, ...data.messages],
        }),
      });

      if (res.status === 429) {
        return { reply: "Rate limit hit — try again in a moment.", error: true };
      }
      if (res.status === 402) {
        return { reply: "AI credits exhausted. Add funds in workspace settings.", error: true };
      }
      if (!res.ok) {
        const t = await res.text();
        return { reply: `AI gateway error ${res.status}: ${t.slice(0, 200)}`, error: true };
      }
      const json: any = await res.json();
      const reply: string = json?.choices?.[0]?.message?.content ?? "(no response)";
      return { reply, error: false };
    } catch (e: any) {
      return { reply: `Network error: ${e?.message ?? e}`, error: true };
    }
  });
