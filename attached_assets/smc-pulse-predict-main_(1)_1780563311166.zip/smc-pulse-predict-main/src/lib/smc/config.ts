// Centralised SMC magic numbers. Tune in one place.
export const SMC_CONFIG = {
  // ── Pivot detection ──────────────────────────────────────────────
  pivotLookback: 3,
  // Pivot prominence filtering happens at the structure level via
  // structureMinSwingAtr (0.8× ATR). No per-pivot threshold needed.

  // ── Liquidity clustering ────────────────────────────────────────
  liquidityTolerance: 0.0015, // fraction of price
  equalLevelTolerance: 0.001,
  // Recency half-life in bars — older pools decay in weighted strength.
  liquidityHalfLifeBars: 200,
  // Session multipliers applied at pool formation (Asia highs/lows are
  // prime NY-session liquidity targets).
  sessionWeight: { Asia: 1.3, London: 1.1, "NY AM": 1.0, "NY PM": 0.9, Off: 0.8 },

  // ── Order Blocks ────────────────────────────────────────────────
  obBodyToRangeRatio: 0.6,
  // Impulse leg away from the OB must be >= this × ATR to qualify.
  obImpulseMinAtr: 1.0,
  // Impulse leg must also create an FVG (true ICT order block).
  obRequireFvg: true,
  // Mitigation: an OB is considered tagged once price trades back through
  // this fraction of its range from the proximal side.
  obMitigationFraction: 0.5,
  // Breaker block: an OB whose extreme (proximal) was swept by a close
  // through on the opposite side becomes a breaker (flipped).
  obBreakerCloseConfirms: true,

  // ── FVG ─────────────────────────────────────────────────────────
  // Gap size must be at least this × ATR of the middle candle to count.
  fvgMinGapAtr: 0.25,
  // Middle (displacement) candle body must be at least this × ATR.
  fvgMinDisplacementAtr: 1.0,
  // Mitigation: FVG removed once price trades into it past this fraction.
  fvgMitigationFraction: 0.5,

  // ── Structure (BOS / CHoCH) ─────────────────────────────────────
  // Break must be confirmed by a candle CLOSE beyond the swing, not just
  // a wick. Wick-only breaks are treated as liquidity sweeps.
  structureRequireClose: true,
  // Minimum swing size in ATR for structure to be considered "trending"
  // rather than ranging. Below this, lastEvent stays "none".
  structureMinSwingAtr: 0.8,

  // ── Displacement classification (legacy) ────────────────────────
  displacementStrong: 1.5,
  displacementModerate: 0.8,

  // ── Volume confirmation ────────────────────────────────────────
  // Simple moving average period for volume spike detection.
  volumeSmaPeriod: 20,
  // Minimum multiple of SMA-volume for a bar to count as a volume spike.
  // Set to 0 to disable (e.g. forex where tick volume is meaningless).
  volumeSpikeMin: 1.5,

  // ── Daily bias overlay ─────────────────────────────────────────
  // Number of daily bars used for macro trend inference.
  dailyBiasLookback: 30,
  // Threshold (in ATR) for a daily swing to be used in trend determination.
  dailyBiasSwingAtr: 0.6,

  // ── PD Array (Premium / Discount) ──────────────────────────────
  // Minimum body/range ratio for a swing to qualify as a dealing-range boundary.
  pdArrayBodyRatio: 0.5,
  // Maximum dealing-range zones to return.
  pdArrayMaxZones: 3,

  // ── Inversion FVGs ─────────────────────────────────────────────
  // Bars after FVG fill to look for a rejection bounce.
  ifvgConfirmationBars: 5,
  // Minimum reversal candle body (in ATR) to confirm inversion.
  ifvgMinReversalAtr: 0.5,

  // ── SMT Divergence ─────────────────────────────────────────────
  // Lookback bars for finding comparable swing points across pairs.
  smtLookbackBars: 30,
  // Minimum swing-high/close difference (in ATR) for a divergence to register.
  smtDivergenceAtr: 0.5,

  // ── UI caps ─────────────────────────────────────────────────────
  maxLiquidityPools: 6,
  maxOrderBlocks: 4,
  maxFvgs: 4,

  // ── Draw scoring ───────────────────────────────────────────────
  drawWeights: { proximity: 0.4, strength: 0.3, bias: 0.3 },
  drawProximityRangePct: 5,
  drawStrengthCap: 4,

  // ── Chat ───────────────────────────────────────────────────────
  chatHistoryLimit: 6,
} as const;

export type SessionName = "Asia" | "London" | "NY AM" | "NY PM" | "Off";

export function sessionForTime(ts: number): SessionName {
  const h = new Date(ts).getUTCHours();
  if (h >= 0 && h < 7) return "Asia";
  if (h >= 7 && h < 12) return "London";
  if (h >= 12 && h < 16) return "NY AM";
  if (h >= 16 && h < 21) return "NY PM";
  return "Off";
}
