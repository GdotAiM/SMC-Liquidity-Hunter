export type Candle = {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type Timeframe = "1m" | "5m" | "15m" | "1h" | "4h" | "1d";
export type AssetClass = "crypto" | "forex";

export const ALL_TIMEFRAMES: Timeframe[] = ["1m", "5m", "15m", "1h", "4h", "1d"];

export const TF_GROUPS: Record<string, Timeframe[]> = {
  scalp: ["1m", "5m", "15m"],
  intraday: ["15m", "1h", "4h"],
  swing: ["1h", "4h", "1d"],
  all: ALL_TIMEFRAMES,
};

export const CRYPTO_SYMBOLS = [
  "BTCUSDT",
  "ETHUSDT",
  "SOLUSDT",
  "BNBUSDT",
  "XRPUSDT",
  "DOGEUSDT",
  "ADAUSDT",
  "AVAXUSDT",
  "LINKUSDT",
  "TONUSDT",
];

// Major + minor forex pairs (Yahoo Finance free, no key)
export const FOREX_SYMBOLS = [
  "EURUSD",
  "GBPUSD",
  "USDJPY",
  "USDCHF",
  "AUDUSD",
  "USDCAD",
  "NZDUSD",
  "EURGBP",
  "EURJPY",
  "GBPJPY",
  "XAUUSD", // gold
  "XAGUSD", // silver
];

export function symbolLabel(s: string, asset: AssetClass) {
  if (asset === "crypto") return s.replace("USDT", "");
  if (s === "XAUUSD") return "GOLD";
  if (s === "XAGUSD") return "SILVER";
  return `${s.slice(0, 3)}/${s.slice(3)}`;
}

export async function fetchCandles(
  asset: AssetClass,
  symbol: string,
  interval: Timeframe,
): Promise<Candle[]> {
  if (asset === "crypto") {
    const { fetchCryptoCandles } = await import("./crypto.functions");
    try {
      return await fetchCryptoCandles({ data: { symbol, interval } });
    } catch {
      // Production fallback: Binance exposes CORS, so keep crypto data alive
      // even if the server-function worker is temporarily unavailable.
      const url = `https://api.binance.com/api/v3/klines?symbol=${encodeURIComponent(
        symbol,
      )}&interval=${interval}&limit=300`;
      const res = await fetch(url, { headers: { Accept: "application/json" } });
      if (!res.ok) throw new Error(`Market data unavailable (${res.status})`);
      const raw: unknown[][] = await res.json();
      return raw.map((r) => ({
        time: Number(r[0]),
        open: Number(r[1]),
        high: Number(r[2]),
        low: Number(r[3]),
        close: Number(r[4]),
        volume: Number(r[5]),
      }));
    }
  }
  const { fetchForexCandles } = await import("./forex.functions");
  return fetchForexCandles({ data: { symbol, interval } });
}
