import { createServerFn } from "@tanstack/react-start";
import type { Candle, Timeframe } from "./market";

/**
 * Server-side Binance fetch. Moves the request off the browser so we avoid
 * CORS surprises, geo-blocks, and per-IP rate limits — and gives us one
 * place to add caching later.
 */
export const fetchCryptoCandles = createServerFn({ method: "GET" })
  .inputValidator((data: { symbol: string; interval: Timeframe; limit?: number }) => data)
  .handler(async ({ data }): Promise<Candle[]> => {
    const limit = Math.min(Math.max(data.limit ?? 300, 50), 1000);
    const params = `symbol=${encodeURIComponent(data.symbol)}&interval=${data.interval}&limit=${limit}`;
    const urls = [
      `https://api.binance.com/api/v3/klines?${params}`,
      `https://api.binance.us/api/v3/klines?${params}`,
    ];

    let res: Response | undefined;
    for (const url of urls) {
      res = await fetch(url, { headers: { Accept: "application/json" } });
      if (res.ok) break;
    }

    if (!res?.ok) throw new Error(`Binance ${res?.status ?? "unreachable"}`);
    const raw: unknown[][] = await res.json();
    return raw.map((r) => ({
      time: r[0] as number,
      open: parseFloat(r[1] as string),
      high: parseFloat(r[2] as string),
      low: parseFloat(r[3] as string),
      close: parseFloat(r[4] as string),
      volume: parseFloat(r[5] as string),
    }));
  });
