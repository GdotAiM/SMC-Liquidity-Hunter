import { createServerFn } from "@tanstack/react-start";
import type { Candle, Timeframe } from "./market";

// Yahoo Finance chart API — no key required. Called server-side to avoid CORS.
const YF_INTERVAL: Record<Timeframe, { interval: string; range: string; aggregate?: number }> = {
  "1m": { interval: "1m", range: "5d" },
  "5m": { interval: "5m", range: "1mo" },
  "15m": { interval: "15m", range: "1mo" },
  "1h": { interval: "60m", range: "3mo" },
  "4h": { interval: "60m", range: "6mo", aggregate: 4 }, // aggregate 4×1h
  "1d": { interval: "1d", range: "2y" },
};

function aggregate(candles: Candle[], factor: number): Candle[] {
  const out: Candle[] = [];
  for (let i = 0; i + factor <= candles.length; i += factor) {
    const slice = candles.slice(i, i + factor);
    out.push({
      time: slice[0].time,
      open: slice[0].open,
      high: Math.max(...slice.map((c) => c.high)),
      low: Math.min(...slice.map((c) => c.low)),
      close: slice[slice.length - 1].close,
      volume: slice.reduce((s, c) => s + c.volume, 0),
    });
  }
  return out;
}

export const fetchForexCandles = createServerFn({ method: "GET" })
  .inputValidator((data: { symbol: string; interval: Timeframe }) => data)
  .handler(async ({ data }): Promise<Candle[]> => {
    const cfg = YF_INTERVAL[data.interval];
    // Yahoo uses "EURUSD=X" style symbols
    const yfSymbol = `${data.symbol.toUpperCase()}=X`;
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${yfSymbol}?interval=${cfg.interval}&range=${cfg.range}`;
    const res = await fetch(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (compatible; LiquidityHunter/1.0; +https://lovable.dev)",
        Accept: "application/json",
      },
    });
    if (!res.ok) throw new Error(`Yahoo ${res.status}`);
    const json: any = await res.json();
    const result = json?.chart?.result?.[0];
    if (!result) throw new Error("No data");
    const ts: number[] = result.timestamp ?? [];
    const q = result.indicators?.quote?.[0];
    if (!q) throw new Error("No quote data");
    const raw: Candle[] = ts
      .map((t, i) => ({
        time: t * 1000,
        open: q.open?.[i],
        high: q.high?.[i],
        low: q.low?.[i],
        close: q.close?.[i],
        volume: q.volume?.[i] ?? 0,
      }))
      .filter(
        (c) =>
          c.open != null && c.high != null && c.low != null && c.close != null,
      ) as Candle[];

    const aggregated = cfg.aggregate ? aggregate(raw, cfg.aggregate) : raw;
    return aggregated.slice(-300);
  });
