// Single source of truth for numeric formatting across the app.
export function fmt(n: number, d = 2): string {
  return n.toLocaleString(undefined, {
    minimumFractionDigits: d,
    maximumFractionDigits: d,
  });
}

export function pct(n: number, d = 2): string {
  return `${n >= 0 ? "" : ""}${n.toFixed(d)}%`;
}

// Heuristic decimals for a given asset/symbol/price.
export function inferDecimals(
  asset: "crypto" | "forex",
  symbol: string,
  price: number | undefined,
): number {
  if (!price) return 2;
  if (asset === "forex") {
    if (symbol.endsWith("JPY")) return 3;
    if (symbol.startsWith("XAU") || symbol.startsWith("XAG")) return 2;
    return 5;
  }
  if (price >= 1000) return 2;
  if (price >= 1) return 4;
  return 6;
}
