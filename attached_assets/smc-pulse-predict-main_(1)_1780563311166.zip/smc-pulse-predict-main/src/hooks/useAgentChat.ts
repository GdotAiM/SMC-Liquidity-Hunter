import { useEffect, useRef, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { agentChat } from "@/lib/smc/chat.functions";
import type { Msg } from "@/components/smc/Chat";
import { SMC_CONFIG } from "@/lib/smc/config";

/**
 * Encapsulates the Intelligence Sheet chat lifecycle:
 *   - seeds agent reasoning bubbles when the sheet opens (per resetKey),
 *   - fires the institutional-summary mutation,
 *   - sends follow-up user turns to the LLM with a capped history window,
 *   - reads `contextBlob` & `messages` from refs to avoid stale closures.
 */
export function useAgentChat({
  open,
  resetKey,
  seed,
  contextBlob,
  summaryPrompt,
  summaryAgentName,
  historyLimit = 10,
}: {
  open: boolean;
  resetKey: string;
  seed: Msg[];
  contextBlob: string;
  summaryPrompt: string;
  summaryAgentName: string;
  historyLimit?: number;
}) {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  // Refs keep mutationFn closures pointing at the latest values without
  // re-creating the mutation (which would otherwise capture the first
  // contextBlob / messages array forever).
  const contextRef = useRef(contextBlob);
  const messagesRef = useRef(messages);
  const seedRef = useRef(seed);
  useEffect(() => {
    contextRef.current = contextBlob;
  }, [contextBlob]);
  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);
  useEffect(() => {
    seedRef.current = seed;
  }, [seed]);

  const summaryMut = useMutation({
    mutationFn: () =>
      agentChat({
        data: {
          context: contextRef.current,
          messages: [{ role: "user", content: summaryPrompt }],
        },
      }),
  });

  const chatMut = useMutation({
    mutationFn: (userMsg: string) => {
      // Send only the last N user/assistant turns; agent seeds stay local.
      const history = messagesRef.current
        .filter((m) => m.role !== "agent")
        .slice(-historyLimit)
        .map((m) => ({
          role: m.role === "assistant" ? ("assistant" as const) : ("user" as const),
          content: m.content,
        }));
      return agentChat({
        data: {
          context: contextRef.current,
          messages: [...history, { role: "user", content: userMsg }],
        },
      });
    },
    onSuccess: (res) =>
      setMessages((m) => [...m, { role: "assistant", content: res.reply }]),
  });

  // Reset & re-seed whenever the sheet opens or the resetKey changes.
  useEffect(() => {
    if (!open) return;
    setMessages(seedRef.current);
    setInput("");
    summaryMut.reset();
    summaryMut.mutate(undefined, {
      onSuccess: (res) =>
        setMessages((m) => [
          ...m,
          { role: "assistant", agent: summaryAgentName, content: res.reply },
        ]),
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, resetKey]);

  // Auto-scroll on new messages.
  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages]);

  const send = () => {
    const t = input.trim();
    if (!t || chatMut.isPending) return;
    setMessages((m) => [...m, { role: "user", content: t }]);
    setInput("");
    chatMut.mutate(t);
  };

  return {
    messages,
    input,
    setInput,
    send,
    scrollRef,
    busy: summaryMut.isPending || chatMut.isPending,
  };
}
